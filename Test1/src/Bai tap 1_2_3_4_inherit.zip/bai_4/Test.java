package bai_4;

import java.util.Arrays;
import java.util.Comparator;

public class Test {
public static void main(String[] args) {
	Integer[] numbers = {5, 2, 8, 1, 9};

    // Sắp xếp mảng theo thứ tự giảm dần
    Arrays.sort(numbers, Comparator.reverseOrder());

    System.out.println("Mảng sau khi sắp xếp giảm dần:");
    for (int number : numbers) {
        System.out.println(number);
    }
}
}
