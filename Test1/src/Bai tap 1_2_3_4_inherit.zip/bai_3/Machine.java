package bai_3;

import java.util.Scanner;



public class Machine {
 private String producer;
 private String address;
 private String brand;
 private float price;
 public Machine () {}
public Machine(String producer, String address, String brand, float price) {
	this.producer = producer;
	this.address = address;
	this.brand = brand;
	this.price = price;
}
public String getProducer() {
	return producer;
}
public void setProducer(String producer) {
	this.producer = producer;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public float getPrice () {
	return price;
	
}
public void setPrice(float price) {
	this.price = price;
}
 public void inPut () {
	 Scanner sc = new Scanner(System.in);
	 System.out.println("Nhap nha san xuat: ");
	 producer = sc.nextLine();
	 System.out.println("Nhap dia chi: ");
	 address = sc.nextLine();
	 System.out.println("Nhap thuong hieu: ");
	 brand = sc.nextLine();
	 System.out.println("Nhap gia: ");
	 price =sc.nextInt();
	 
 } 
 public void outPut () {
	 System.out.println("Nha sản xuat: "+producer);
	 System.out.println("Dia chi: " + address);
	 System.out.println("Nhan hieu: "+brand);
	 System.out.println("Gia sản pham: "+price);
 }
 
}
